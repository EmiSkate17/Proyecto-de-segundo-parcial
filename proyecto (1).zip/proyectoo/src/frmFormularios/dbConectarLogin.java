/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frmFormularios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author emili
 */
public class dbConectarLogin {
    static String url="jdbc:mysql://localhost:3306/proyectoo";
    public static Connection con=null;
    public static Connection conectarTemporal(String user, String pass) {
    Connection tempCon = null;
    try {
        tempCon = DriverManager.getConnection(url, user, pass);
        System.out.println("Conexion temporal Exitosa para usuario: " + user);
    }
    catch (SQLException e) 
    {
        System.out.println("Fallo de conexion temporal para usuario: " + user);
        tempCon = null; 
    }
        return tempCon;
    }
    public void desconectarTemporal(Connection con) {
    try {
        if (con != null) {
            con.close();
            System.out.println("Conexion temporal cerrada.");
        }
    } catch (SQLException e) {
        System.out.println("Fallo al cerrar conexion temporal.");
    }
}
}
