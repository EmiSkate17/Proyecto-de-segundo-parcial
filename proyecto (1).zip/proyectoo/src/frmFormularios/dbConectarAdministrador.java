/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frmFormularios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author emili
 */
public class dbConectarAdministrador {
    static String url="jdbc:mysql://localhost:3306/proyectoo";
    static String user="administrador";
    static String pass="123*";
    public static Connection con=null;
    public static Connection conectarAdmin()
    {
        try
        {
            con=DriverManager.getConnection(url, user, pass);
            System.out.println("Conexion Exitosa");
        }
        catch(SQLException e)
        {
            System.out.println("Error de conexion");
            e.printStackTrace();
        }
        return con;
    }
    public void desconectarAdmin()
    {
        try
        {
            con.close();
            System.out.println("Base de datos desconectada de forma exitosa");
        }
        catch(SQLException e)
        {
            System.out.println("Fallo al momento de desconectar");
        }
    }
}
