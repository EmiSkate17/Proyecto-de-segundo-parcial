/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frmFormularios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author emili
 */
public class dbConectarComprobante {
    static String url="jdbc:mysql://localhost:3306/proyectoo";
    static String user="comprobador";
    static String pass="1234*";
    
    public static Connection con=null;
    public static Connection conectarComprobante()
    {
        try
        {
            con=DriverManager.getConnection(url, user, pass);
            System.out.println("Conexion Exitosa");
        }
        catch(SQLException e)
        {
            System.out.println("Error de conexion");
            e.printStackTrace();
        }
        return con;
    }
    public void desconectarComprobante()
    {
        try
        {
            con.close();
            System.out.println("Base de datos desconectada de forma exitosa");
        }
        catch(SQLException e)
        {
            System.out.println("Fallo al momento de desconectar");
        }
    }
}
