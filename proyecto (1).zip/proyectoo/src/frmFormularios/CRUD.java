/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frmFormularios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author emili
 */
public class CRUD {
    public void insertarProveedor(String idP, String nom, String ie)
    {
        String a="INSERT INTO proveedor (id_Proveedor, nombre, id_empleado)Values (?, ?, ?)";
        try
        {
            Connection click = dbConectarAdministrador.conectarAdmin();
            PreparedStatement ps=click.prepareStatement(a);
         
             ps.setString(1, idP);
             ps.setString(2,nom);
             ps.setString(3, ie);
             
             ps.executeUpdate();
             
             System.out.println("proveedor registrado con exito");
        }
        catch(SQLException e)
        {
            System.out.println("fallo al registrar al proveedor");
            e.printStackTrace();
        }
    }
    public void eliminarProveedor(String idP)
    {
        String d="DELETE FROM proveedor WHERE id_proveedor=?";
        try
        {
            Connection click = dbConectarAdministrador.conectarAdmin();
            PreparedStatement pg=click.prepareStatement(d);
            pg.setString(1, idP);
            int filasAfectadas=pg.executeUpdate();
            if(filasAfectadas>0)
            {
                System.out.println("proveedor con ID: " +idP+ " Eliminado con exito");
            }
            else
            {
                System.out.println("No se encontro un proveedor con ese ID");
            }         
        }
        catch(SQLException e)
        {
          System.out.println("Fallo al eliminar un proveedor\n");
          e.printStackTrace();
        }
    }
   public void modificarProveedor(String nP, String idnomm)
    {
        String f="UPDATE proveedor SET nombre = ? WHERE id_proveedor=?";
        try
        {
            Connection click = dbConectarAdministrador.conectarAdmin();
            PreparedStatement ph=click.prepareStatement(f);
            ph.setString(1, nP);
            ph.setString(2, idnomm);
            
            ph.executeUpdate();
            System.out.println("Nombre del proveedor cambiado con exito");
        }
        catch(SQLException e)
        {
          System.out.println("Fallo al modificar el nomre\n");
          e.printStackTrace();   
        }
    }
   public DefaultTableModel mostrar() {
        
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID proveedor");
        modelo.addColumn("Nombre proveedor");
        modelo.addColumn("ID empleado");
        
        String q = "SELECT id_proveedor, nombre, id_empleado FROM proveedor";
        
        dbConectarAdministrador click = new dbConectarAdministrador();
        
        try (Connection con = click.conectarAdmin();
             PreparedStatement pa = con.prepareStatement(q);
             ResultSet leer = pa.executeQuery()) {

            
            while (leer.next()) {
                
                Object[] fila = new Object[3];
                fila[0] = leer.getInt("id_proveedor");          
                fila[1] = leer.getString("nombre");       
                fila[2] = leer.getInt("id_empleado");      
                modelo.addRow(fila);
            }
            
        } catch (SQLException e) {
            
            e.printStackTrace();
        }
        return modelo;
    }
   public DefaultTableModel mostrar2() {
        
        DefaultTableModel modelo2 = new DefaultTableModel();
        modelo2.addColumn("ID venta");
        modelo2.addColumn("Fecha");
        modelo2.addColumn("ID Empleado");
        modelo2.addColumn("ID Cliente");
        
        String w = "SELECT id_venta, fecha, id_empleado, id_cliente FROM venta";
        
        dbConectarComprobante click = new dbConectarComprobante();
        
        try (Connection con = click.conectarComprobante();
             PreparedStatement pm = con.prepareStatement(w);
             ResultSet leer = pm.executeQuery()) {
            while (leer.next()) {
                
                Object[] fila = new Object[4];
                fila[0] = leer.getString("id_venta");          
                fila[1] = leer.getDate("fecha");       
                fila[2] = leer.getString("id_empleado");      
                fila[3] = leer.getString("id_cliente");     
                modelo2.addRow(fila);
            }
            
        } catch (SQLException e) {
            
            e.printStackTrace();
        }
        return modelo2;
    }
   // Verifica si las credenciales son válidas y retorna su rol.
    public String verificarRol(String usuario, String password) {
        
        Connection con = null;
        String rol = null;
        con = dbConectarLogin.conectarTemporal(usuario, password); 
        
        try {
            if (con != null) {
                if (usuario.equalsIgnoreCase("administrador")) {
                    rol = "ADMINISTRADOR";
                } else if (usuario.equalsIgnoreCase("comprobador")) {
                    rol = "COMPROBADOR";
                } 
            }
        } finally {
            dbConectarLogin db = new dbConectarLogin();
            db.desconectarTemporal(con);
        }
        return rol;
    } 
}
